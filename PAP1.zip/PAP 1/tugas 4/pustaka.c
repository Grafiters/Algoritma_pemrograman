#include "header.h"

void print_nama()
{
    printf("Nama Lengkap = Bayu Grafit Nur Alfian\n");
}
