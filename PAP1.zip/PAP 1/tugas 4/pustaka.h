#include "header.h"

void print_identitas()
{
    printf("NIM = A11.2017.10284\n");
    printf("Nama Lengkap = Bayu Grafit Nur Alfian\n");
    printf("Alamat = Pulokulon, Purwodadi\n");
}
