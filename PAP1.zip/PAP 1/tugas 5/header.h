#include <stdio.h>
#include <stdlib.h>

int len_text();
