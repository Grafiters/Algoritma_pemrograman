#include "header.h"

/*
    Nama     = Bayu Grafit Nur Alfian
    NIM      = A11.2017.10284
    Kelompok = 4207
    PAP 1    = tugas 5
*/

int main()
{
    len_text();
    return 0;
}
