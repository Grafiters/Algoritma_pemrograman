#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

int maxs(int angka[], int batas);

#endif // HEADER_H_INCLUDED
