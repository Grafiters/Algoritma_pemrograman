#ifndef PUSTAKA_H_INCLUDED
#define PUSTAKA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int is_kabisat(int years);
int hitung_vokal(char text[]);

int checkprime(int prime);
void cetakprima(int prima);

void char_frequency(char text[]);

#endif // PUSTAKA_H_INCLUDED
