#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int is_kabisat(int years);

#endif // HEADER_H_INCLUDED
