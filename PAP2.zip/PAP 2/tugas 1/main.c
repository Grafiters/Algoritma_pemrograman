#include "header.h"

/*
    Nama     : Bayu Grafit Nur Alfian
    NIM      : A1.2017.10284
    Kelompok : A11.4207
*/

int years;

int main()
{
    printf("====== Tugas 1 make kabisat years ======\n");

    printf("Masukan tahun: "); scanf("%d",&years);
    is_kabisat(years);
    return 0;
}
