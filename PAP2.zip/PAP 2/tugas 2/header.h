#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

int hitung_vokal(char text[]);
char text[];


#endif // HEADER_H_INCLUDED
