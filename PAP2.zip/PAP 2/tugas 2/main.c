#include "header.h"


/*
    Nama     : Bayu Grafit Nur Alfian
    NIM      : A1.2017.10284
    Kelompok : A11.4207
*/


int main()
{
    printf("Masukan text: "); gets(text);
    printf("Total huruf vokal pada teks tersebut adalah: %d\n",hitung_vokal(text));

    return 0;
}

