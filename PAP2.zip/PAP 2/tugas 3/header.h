#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

int checkprime(int prime);
void cetakprima(int prima);


#endif // HEADER_H_INCLUDED
