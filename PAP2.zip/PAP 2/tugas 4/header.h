#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void char_frequency(char text[]);


#endif // HEADER_H_INCLUDED
