#include "header.h"


/*
    Nama     : Bayu Grafit Nur Alfian
    NIM      : A1.2017.10284
    Kelompok : A11.4207
*/


char text[];

int main()
{
    printf("Masukkan kata-kata = "); gets(text);
    char_frequency(text);
    return 0;
}
