#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void diamond(int row);

#endif // HEADER_H_INCLUDED
