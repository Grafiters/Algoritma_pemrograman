#include "header.h"


/*
    Nama     : Bayu Grafit Nur Alfian
    NIM      : A1.2017.10284
    Kelompok : A11.4207
*/


int row;
int main()
{
    printf("Masukkan baris = "); scanf("%d", &row);

    diamond(row);
    return 0;
}
