#include <stdio.h>
#include <stdlib.h>

int count_array(int data[], int jml_data);

int data;

int main()
{
    int i;
    for(i=0;i<)
    return 0;
}

int count_array(int data[], int jml_data){
    int i, jml=0;
    i=0;
    while(i<jml_data-1){
        if(data[i]!='\0'){
            jml++;
        }
    }
    return jml
}
